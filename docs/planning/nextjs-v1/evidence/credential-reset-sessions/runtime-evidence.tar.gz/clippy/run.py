import hashlib,json,os,secrets,signal,subprocess,time
from pathlib import Path
root=Path('/Users/jasonlee/Developer/frontend/.worktrees/attendance-web-session')
a=Path(__file__).parent/'quality-final';a.mkdir()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head=='930a04d71053314d6172331ca14a939e1df8b459'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
docker=['docker','--context','colima-nextjs-v1-auth']
nonce=secrets.token_hex(6);name='reset-sessions-clippy-'+nonce;label='console.reset-sessions-clippy='+nonce
cache=Path('/Users/jasonlee/Developer/frontend/.artifacts/acceptance/device-login-source-revocation/linux')
command=docker+['run','--rm','--pull=never','--name',name,'--label',label,'--network','none','--mount',f'type=bind,source={root}/backend-fork,target=/candidate,readonly','--mount',f'type=bind,source={cache}/cargo-home,target=/cargo-home','--mount',f'type=bind,source={cache}/target,target=/target','--workdir','/candidate/backend']
for value in ('CARGO_HOME=/cargo-home','CARGO_TARGET_DIR=/target','RUSTUP_TOOLCHAIN=1.98.1','CARGO_BUILD_JOBS=1','CARGO_INCREMENTAL=0','CARGO_PROFILE_DEV_DEBUG=0','CARGO_PROFILE_TEST_DEBUG=0','SQLX_OFFLINE=true'):command+=['--env',value]
command+=['sha256:1038295e936ce19587f8ced4ae29631ab1f0e548da45efbdf77d5087bd3ed9a2','cargo','clippy','--locked','--offline','-p','console-app','-p','console-platform-provisioning','--lib','--test','auth_rest','--test','account_locking','--test','account_identity','--test','rls_auth_chain_as_runtime_role','--','-D','warnings']
r={'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'candidate_head':head,'command':command,'status':'unreached','started':time.time()}
sources=['backend-fork/backend/crates/platform/provisioning/src/lib.rs','backend-fork/backend/app/tests/auth_rest.rs','backend-fork/backend/app/tests/auth_rest/reset_sessions.rs','backend-fork/backend/crates/platform/provisioning/tests/account_identity.rs','backend-fork/tools/lanes/pgtest.sh']
r['source_sha256']={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in sources}
try:
 with subprocess.Popen(command,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True) as process:
  try:out,err=process.communicate(timeout=1800)
  except subprocess.TimeoutExpired:
   r['timed_out']=True;os.killpg(process.pid,signal.SIGKILL);out,err=process.communicate(timeout=30)
  r['exit_code']=process.returncode
 for n,b in (('stdout',out),('stderr',err)):
  (a/(n+'.log')).write_bytes(b);r[n+'_sha256']=hashlib.sha256(b).hexdigest()
finally:
 ids=subprocess.check_output(docker+['ps','-aq','--filter','label='+label],text=True).splitlines()
 for identifier in ids:
  own=subprocess.check_output(docker+['inspect','--format','{{index .Config.Labels "console.reset-sessions-clippy"}}',identifier],text=True).strip()
  assert own==nonce
  subprocess.run(docker+['rm','-fv',identifier],check=True,capture_output=True)
 r['cleanup_passed']=not subprocess.check_output(docker+['ps','-aq','--filter','label='+label]).strip()
 r['source_revalidation_passed']=head==subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip() and not subprocess.check_output(['git','status','--porcelain'],cwd=root) and r['source_sha256']=={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in sources}
 r['status']='passed' if r.get('exit_code')==0 and not r.get('timed_out') and r['cleanup_passed'] and r['source_revalidation_passed'] else 'failed'
 r['finished']=time.time();(a/'report.json').write_text(json.dumps(r,indent=2)+'\n')
 print(a/'report.json')
raise SystemExit(0 if r['status']=='passed' else 1)
