#!/usr/bin/env python3
"""Record credential-reset session regression suite in isolated Linux containers against disposable PostgreSQL 18.

Exit 1 means complete execution with only independently approved behavioral assertion failures.
Exit 126 means invalid/incomplete evidence; fanout.py must refuse admission.
"""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import signal
import subprocess
import tempfile
import time
from urllib.parse import urlencode


DOCKER_CONTEXT = "colima-nextjs-v1-auth"
RUST_IMAGE = "rust@sha256:218765d808d35e2e3fa1b12b2e1314e2bfdd427a3530de071398553a95743cba"
POSTGRES_IMAGE = "postgres:18.4@sha256:65f70a152846cf504dff86e807007e9aeac98c3aeb7b62541b2c55ab9d264e56"
APPROVED_TESTS_HEAD = "7cbb78fb2a500f413ed73242b082aa1f03c7fb52"
APPROVED_TEST_SOURCE_SHA256 = "68c0bbe780b4be7e63d82cd5151aebc7d8f17e66de814b5b8b80f46dc2a334c7"
APPROVED_EXPECTATIONS_SHA256 = "b561d81f8b4b24a5c412b938e19ae2e5fa8b3c99563e2b5994175732a6073b93"
SUITES = (("auth_rest", "console-app", "auth_rest", 39),)
BASELINE_HEAD = "dc4a7bb35e4a829b71c3f32a72483765e060e321"
SOURCE_ROOTS = ("backend", "third-party", "ops/postgres-reconcile-topology.sh", "rust-toolchain.toml", ".cargo")
TEST_ROOTS = ("backend/app/tests", "backend/crates/platform/provisioning/tests", "backend/crates/platform/auth/tests",
              "backend/crates/platform/db/tests", "backend/crates/platform/test-support")
INLINE_TESTS = ()
REQUIRED_SOURCES = ("backend/Cargo.toml", "backend/Cargo.lock", "ops/postgres-reconcile-topology.sh",
                    "backend/crates/platform/provisioning/src/lib.rs", "backend/crates/platform/auth/src/refresh.rs",
                    "backend/app/tests/auth_rest/reset_sessions.rs",
                    "backend/crates/platform/test-support/src/lib.rs")
RESULT = re.compile(rb"test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out")
FAILURE_HEADER = re.compile(rb"^---- (.+) stdout ----$", re.MULTILINE)
PANIC = re.compile(rb"^thread '[^\n]+'(?: \(\d+\))? panicked at ([^\n]+):(\d+):(\d+):\n([^\n]*)$", re.MULTILINE)
SUITE_TEST_SOURCES = {"auth_rest": ("backend/app/tests/auth_rest.rs",)}
EXECUTED = re.compile(rb"^test (.+) \.\.\. (ok|FAILED|ignored)(?:,.*)?$", re.MULTILINE)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def check_behavioral_failures(output, failed_names, expected, candidate):
    """Accept only unambiguous libtest details at reviewed new-test assertions."""
    parsed = []
    issues = []
    sections = list(re.finditer(rb"^failures:$", output, re.MULTILINE))
    if not failed_names:
        if sections or FAILURE_HEADER.search(output) or b"panicked at " in output:
            issues.append("passed output contains unexpected failure/panic sections")
        return {"status": "failed" if issues else "passed", "failures": [], "issues": issues}
    if len(sections) != 2:
        return {"status": "failed", "failures": [], "issues": ["failure sections are absent, duplicated or ambiguous"]}
    details = output[sections[0].end():sections[1].start()]
    summary = output[sections[1].end():]
    result_start = re.search(rb"^test result:", summary, re.MULTILINE)
    summary_names = [line.decode("utf-8").strip() for line in summary[:result_start.start()].splitlines()
                     if line.strip()] if result_start else []
    headers = list(FAILURE_HEADER.finditer(details))
    names = [header.group(1).decode("utf-8") for header in headers]
    if (sorted(names) != sorted(failed_names) or len(set(names)) != len(names)
            or sorted(summary_names) != sorted(failed_names)):
        issues.append("failure detail/summary names do not match the executed failures exactly")
    if (len(list(FAILURE_HEADER.finditer(output))) != len(headers)
            or output.count(b"panicked at ") != details.count(b"panicked at ")
            or details.count(b"panicked at ") != len(headers)):
        issues.append("extra or ambiguous failure/panic blocks")
    for index, header in enumerate(headers):
        name = names[index]
        end = headers[index + 1].start() if index + 1 < len(headers) else len(details)
        block = details[header.end():end]
        panics = list(PANIC.finditer(block))
        entry = expected.get(name)
        if entry is None:
            issues.append(f"unexpected or baseline failure: {name}")
        if len(panics) != 1:
            issues.append(f"failure does not have exactly one assertion panic: {name}")
            continue
        panic = panics[0]
        path = panic.group(1).decode("utf-8")
        line, column = int(panic.group(2)), int(panic.group(3))
        message = panic.group(4).decode("utf-8")
        parsed.append({"test_name": name, "panic_path": path, "line": line,
                       "column": column, "panic_message": message})
        if entry is not None:
            allowed_paths = (entry["source_path"], entry["source_path"].removeprefix("backend/"),
                             str(candidate / entry["source_path"]),
                             "/candidate/" + entry["source_path"],
                             "/candidate/" + entry["source_path"].removeprefix("backend/"))
            if (path not in allowed_paths or line != entry["line"]
                    or not message.startswith(entry["panic_message_prefix"])):
                issues.append(f"panic is not the reviewed behavioral assertion: {name}")
            tail_lines = [line.strip() for line in block[panic.end():].decode("utf-8").splitlines() if line.strip()]
            if tail_lines[:len(entry["panic_detail_lines"])] != entry["panic_detail_lines"]:
                issues.append(f"panic result values are not the reviewed missing behavior: {name}")
    return {"status": "failed" if issues else "passed", "failures": parsed, "issues": issues}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--cargo-home", type=Path, required=True)
    parser.add_argument("--target-dir", type=Path, required=True)
    parser.add_argument("--expected-head", required=True)
    parser.add_argument("--approved-tests-head", required=True)
    parser.add_argument("--approved-red-expectations", type=Path, required=True)
    parser.add_argument("--approved-red-expectations-sha256", required=True)
    args = parser.parse_args()
    if not all(re.fullmatch(r"[0-9a-f]{40}", value) for value in (args.expected_head, args.approved_tests_head)):
        parser.error("candidate and approved test heads must be immutable full SHA-1 IDs")
    if args.approved_tests_head != APPROVED_TESTS_HEAD:
        parser.error("test commit is not this runner's independently approved immutable source")
    if args.approved_red_expectations_sha256 != APPROVED_EXPECTATIONS_SHA256:
        parser.error("RED expectations are not this runner's independently approved immutable input")
    if not re.fullmatch(r"[0-9a-f]{64}", args.approved_red_expectations_sha256):
        parser.error("reviewed RED expectations require an immutable full SHA-256")
    if args.approved_red_expectations.is_symlink():
        parser.error("reviewed RED expectations cannot be a symlink")
    expectations_path = args.approved_red_expectations.resolve(strict=True)
    if expectations_path.is_symlink() or not expectations_path.is_file():
        parser.error("reviewed RED expectations must be one regular file")
    expectations_bytes = expectations_path.read_bytes()
    if digest(expectations_bytes) != args.approved_red_expectations_sha256:
        parser.error("reviewed RED expectations differ from their approved SHA-256")
    expectations = json.loads(expectations_bytes)
    if (set(expectations) != {"schema_version", "approved_tests_head", "baseline_head", "expected_discovery", "failures"}
            or type(expectations["schema_version"]) is not int or expectations["schema_version"] != 1
            or expectations["approved_tests_head"] != args.approved_tests_head
            or expectations["baseline_head"] != BASELINE_HEAD
            or not isinstance(expectations["expected_discovery"], dict)
            or set(expectations["expected_discovery"]) != set(SUITE_TEST_SOURCES)
            or not isinstance(expectations["failures"], list)):
        parser.error("RED expectations must pin the approved test commit and original baseline")
    candidate = args.candidate.resolve(strict=True)
    cargo_home = args.cargo_home.resolve(strict=True)
    target_dir = args.target_dir.resolve(strict=True)
    if (not cargo_home.is_dir() or not target_dir.is_dir() or cargo_home == target_dir
            or cargo_home.is_relative_to(candidate) or target_dir.is_relative_to(candidate)):
        parser.error("private Cargo cache and target must be distinct directories outside the candidate")
    cache_entries = {"registry", "git", ".package-cache", ".package-cache-mutate",
                     ".global-cache", ".global-cache-journal", ".global-cache-wal", ".global-cache-shm"}
    if any(path.is_symlink() or path.name not in cache_entries for path in cargo_home.iterdir()):
        parser.error("private Linux Cargo home may contain only registry/git caches and Cargo cache locks/databases")
    if digest((candidate / "backend/app/tests/auth_rest/reset_sessions.rs").read_bytes()) != APPROVED_TEST_SOURCE_SHA256:
        parser.error("reviewed test source differs from its exact SHA-256")
    head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=candidate, text=True).strip()
    if head != args.expected_head or subprocess.check_output(["git", "status", "--porcelain"], cwd=candidate):
        parser.error("candidate must be the clean exact test/source commit")
    repo_root = Path(subprocess.check_output(["git", "rev-parse", "--show-toplevel"], cwd=candidate, text=True).strip())
    prefix = candidate.relative_to(repo_root)
    approved_head = subprocess.check_output(
        ["git", "rev-parse", "--verify", args.approved_tests_head + "^{commit}"],
        cwd=candidate, text=True).strip()
    if subprocess.run(["git", "merge-base", "--is-ancestor", approved_head, head], cwd=candidate).returncode:
        parser.error("approved test commit must be an ancestor of the candidate")
    custody_roots = [str(prefix / path) for path in SOURCE_ROOTS] + [".github/workflows/ci.yml"]
    index_entries = subprocess.check_output(
        ["git", "ls-files", "--stage", "-z", "--"] + custody_roots, cwd=repo_root).split(b"\0")
    source_hashes = {}
    git_sources = []
    test_paths = []
    for entry in index_entries:
        if not entry:
            continue
        metadata, raw_path = entry.split(b"\t", 1)
        mode, _, stage = metadata.decode().split()
        git_path = raw_path.decode("utf-8")
        if mode not in ("100644", "100755") or stage != "0":
            parser.error(f"source must be one regular tracked blob: {git_path}")
        source = repo_root / git_path
        if not source.is_file() or source.is_symlink():
            parser.error(f"source must be a regular local file: {git_path}")
        data = source.read_bytes()
        committed = subprocess.check_output(["git", "show", f"{head}:{git_path}"], cwd=repo_root)
        if data != committed:
            parser.error(f"source bytes differ from exact HEAD: {git_path}")
        source_hashes[str(source)] = digest(data)
        git_sources.append(git_path)
        if any(git_path == str(prefix / path) or git_path.startswith(str(prefix / path) + "/")
               for path in TEST_ROOTS):
            test_paths.append(git_path)
            if data != subprocess.check_output(["git", "show", f"{approved_head}:{git_path}"], cwd=repo_root):
                parser.error(f"test/helper source differs from approved test commit: {git_path}")
    missing = set(str(prefix / path) for path in REQUIRED_SOURCES) - set(git_sources)
    if missing or ".github/workflows/ci.yml" not in git_sources:
        parser.error(f"required source custody is incomplete: {sorted(missing)}")
    approved_test_paths = subprocess.check_output(
        ["git", "ls-tree", "-r", "--name-only", "-z", approved_head, "--"]
        + [str(prefix / path) for path in TEST_ROOTS], cwd=repo_root).decode("utf-8").split("\0")
    if sorted(test_paths) != sorted(path for path in approved_test_paths if path):
        parser.error("tracked test/helper closure differs from approved test commit")

    inline_hashes = {}
    for path, marker in INLINE_TESTS:
        git_path = str(prefix / path)
        current = subprocess.check_output(["git", "show", f"{head}:{git_path}"], cwd=repo_root)
        approved = subprocess.check_output(["git", "show", f"{approved_head}:{git_path}"], cwd=repo_root)
        if current.count(marker) != 1 or approved.count(marker) != 1:
            parser.error(f"inline test module must have exactly one boundary: {git_path}")
        if current.split(marker)[1] != approved.split(marker)[1]:
            parser.error(f"inline tests differ from independently approved test source: {git_path}")
        inline_hashes[git_path] = digest(current.split(marker)[1])

    if subprocess.run(["git", "merge-base", "--is-ancestor", BASELINE_HEAD, approved_head],
                      cwd=candidate).returncode:
        parser.error("original baseline must be an ancestor of the approved tests")
    expected_by_suite = {name: {} for name, _, _, _ in SUITES}
    for name, _, _, minimum in SUITES:
        names = expectations["expected_discovery"][name]
        if (not isinstance(names, list) or len(names) < minimum
                or not all(isinstance(test_name, str) and test_name for test_name in names)
                or len(set(names)) != len(names)):
            parser.error("reviewed discovery must pin every unique selected test name")
    for entry in expectations["failures"]:
        if (not isinstance(entry, dict)
                or set(entry) != {"suite", "test_name", "source_path", "line", "assertion_line_sha256", "panic_message_prefix", "panic_detail_lines", "assertion_function"}
                or entry.get("suite") not in expected_by_suite
                or not isinstance(entry.get("test_name"), str)
                or not re.fullmatch(r"[A-Za-z_][A-Za-z_0-9]*(?:::[A-Za-z_][A-Za-z_0-9]*)*", entry["test_name"])
                or not isinstance(entry.get("source_path"), str)
                or not any(entry["source_path"] == path or entry["source_path"].startswith(path.removesuffix(".rs") + "/")
                           for path in SUITE_TEST_SOURCES[entry["suite"]])
                or type(entry.get("line")) is not int or entry["line"] < 1
                or not isinstance(entry.get("assertion_line_sha256"), str)
                or not re.fullmatch(r"[0-9a-f]{64}", entry["assertion_line_sha256"])
                or not isinstance(entry.get("panic_message_prefix"), str)
                or not entry["panic_message_prefix"] or "\n" in entry["panic_message_prefix"]
                or not isinstance(entry.get("panic_detail_lines"), list)
                or not all(isinstance(value, str) and value and "\n" not in value
                           for value in entry["panic_detail_lines"])):
            parser.error("RED expectation is not an exact suite/new-test/source assertion entry")
        if entry["test_name"] not in expectations["expected_discovery"][entry["suite"]]:
            parser.error("reviewed behavioral test must belong to the exact discovery census")
        if entry["test_name"] in expected_by_suite[entry["suite"]]:
            parser.error("RED expectations contain a duplicate suite/test identity")
        git_path = str(prefix / entry["source_path"])
        approved_source = subprocess.check_output(
            ["git", "show", f"{approved_head}:{git_path}"], cwd=repo_root).decode("utf-8")
        source_lines = approved_source.splitlines()
        if (entry["line"] > len(source_lines)
                or not re.match(r"\s*assert(?:_eq|_ne)?!\s*\(", source_lines[entry["line"] - 1])):
            parser.error("reviewed RED location must be an explicit assertion, never fixture unwrap/expect")
        if digest(source_lines[entry["line"] - 1].encode("utf-8")) != entry["assertion_line_sha256"]:
            parser.error("reviewed behavioral assertion line differs from its exact source hash")
        test_function = entry["test_name"].split("::")[-1]
        function = entry["assertion_function"]
        if not isinstance(function, str) or not re.fullmatch(r"[A-Za-z_][A-Za-z_0-9]*", function):
            parser.error("reviewed assertion helper must be an explicit function name")
        test_pattern = re.compile(r"^async fn " + re.escape(test_function) + r"\s*\(", re.MULTILINE)
        if len(test_pattern.findall(approved_source)) != 1:
            parser.error("reviewed RED test must exist exactly once")
        function_pattern = re.compile(r"^\s*(?:async\s+)?fn\s+" + re.escape(function) + r"\s*\(", re.MULTILINE)
        function_matches = list(function_pattern.finditer(approved_source))
        if len(function_matches) != 1:
            parser.error("reviewed RED test function must exist exactly once in approved source")
        function_line = approved_source[:function_matches[0].start()].count("\n") + 1
        following_function = re.search(r"^\s*(?:async\s+)?fn\s+", approved_source[function_matches[0].end():], re.MULTILINE)
        next_line = (approved_source[:function_matches[0].end() + following_function.start()].count("\n") + 1
                     if following_function else len(source_lines) + 1)
        if not function_line <= entry["line"] < next_line:
            parser.error("reviewed RED assertion must be inside its new test function")
        baseline_exists = subprocess.check_output(
            ["git", "ls-tree", "--name-only", BASELINE_HEAD, "--", git_path], cwd=repo_root)
        if baseline_exists:
            baseline_source = subprocess.check_output(
                ["git", "show", f"{BASELINE_HEAD}:{git_path}"], cwd=repo_root).decode("utf-8")
            if function_pattern.search(baseline_source) or test_pattern.search(baseline_source):
                parser.error("baseline tests cannot be allowlisted as behavioral RED")
        expected_by_suite[entry["suite"]][entry["test_name"]] = entry

    changed_sources = subprocess.check_output(
        ["git", "diff", "--name-only", BASELINE_HEAD, head, "--"] + [str(prefix / path) for path in SOURCE_ROOTS],
        cwd=repo_root, text=True).splitlines()
    product_changes = [path for path in changed_sources if path not in test_paths]
    run_dir = Path(__file__).resolve().parent / datetime.now(timezone.utc).strftime("run-%Y%m%dT%H%M%S.%fZ")
    run_dir.mkdir(parents=True)
    report = {
        "scope": "single-site disposable PostgreSQL 18 credential-reset session revocation; full 39-test census, 9 reset tests executed and 30 filtered; full authentication diagnostics reported separately; not browser, two-site durability or release acceptance",
        "status": "unreached",
        "runner_sha256": digest(Path(__file__).read_bytes()),
        "probe_sha256": digest(Path(__file__).with_name("probe.py").read_bytes()),
        "candidate_head": head,
        "product_changes_from_baseline": product_changes,
        "approved_tests_head": approved_head,
        "candidate": str(candidate),
        "docker_context": DOCKER_CONTEXT,
        "runtime_images": {"rust": RUST_IMAGE, "postgres": POSTGRES_IMAGE},
        "cargo_home": str(cargo_home), "target_dir": str(target_dir),
        "postgres_tool_versions": {},
        "postgres_server_version": None,
        "approved_red_expectations": str(expectations_path),
        "approved_red_expectations_sha256": digest(expectations_bytes),
        "reviewed_behavioral_assertions": expectations["failures"],
        "reviewed_discovery": expectations["expected_discovery"],
        "source_sha256": source_hashes,
        "custody_source_count": len(source_hashes),
        "approved_test_paths": test_paths,
        "inline_test_sha256": inline_hashes,
        "test_failure_candidate": False,
        "proof_limits": ["Runtime-role in-process production Routers and exact PostgreSQL lock/blocker witnesses; fixture bearer authentication is not browser/passkey/identity-proofing acceptance.",
                         "Only seven independently pinned missing-reset-revocation assertions are admissible behavioral RED; build, setup, migration, timeout or other failures are invalid evidence.",
                         "Discover all 39 tests, execute all nine reset_sessions:: tests without omissions, record 30 filtered tests explicitly; execute full 39 separately and retain the two inherited enrollment-purpose failures as unresolved HOLDs."],
        "commands": [],
        "suites": [{"name": name, "package": package, "target": target,
                    "exact_filter": "reset_sessions::", "baseline_minimum": baseline_minimum, "status": "unreached", "discovered": None,
                    "discovered_names": [], "executed_names": [], "execution_outcomes": {}, "executed": 0, "passed": 0, "failed": 0,
                    "selected": None, "selected_names": [], "expected_filtered": None,
                    "execution_complete": False, "behavioral_red": {"status": "unreached", "failures": [], "issues": []},
                    "ignored": 0, "measured": 0, "filtered": 0, "exit_code": None}
                   for name, package, target, baseline_minimum in SUITES],
    }
    passwords = {name: secrets.token_hex(32) for name in (
        "POSTGRES_ADMIN_PASSWORD", "CONSOLE_APP_POSTGRES_PASSWORD", "CONSOLE_RT_POSTGRES_PASSWORD",
        "CONSOLE_LEAVE_COMMAND_POSTGRES_PASSWORD", "CONSOLE_ONTOLOGY_COMMAND_POSTGRES_PASSWORD",
        "CONSOLE_PLATFORM_FORCE_COMMAND_POSTGRES_PASSWORD",
    )}
    base_env = {name: value for name in ("PATH", "HOME", "TMPDIR", "LANG", "LC_ALL")
                if (value := os.environ.get(name)) is not None}
    docker = ["docker", "--context", DOCKER_CONTEXT]
    nonce = secrets.token_hex(6)
    ownership_label = "console.reset-sessions-run=" + nonce
    network = "reset-sessions-" + nonce
    pg_name = network + "-pg"
    containers = [pg_name]
    volumes = set()
    temp = None
    artifact_paths = (Path(__file__).resolve(), Path(__file__).with_name("probe.py").resolve())
    artifact_hashes = {str(artifact_paths[0]): report["runner_sha256"],
                       str(artifact_paths[1]): report["probe_sha256"]}
    report["runtime_resources"] = {"network": network, "containers": containers,
                                   "ownership_label": ownership_label,
                                   "postgres_anonymous_volumes": [], "cleanup": []}

    def interrupted(signum, _frame):
        raise RuntimeError(f"runner interrupted by signal {signum}; owned resources require cleanup")

    old_handlers = {signum: signal.signal(signum, interrupted) for signum in (signal.SIGINT, signal.SIGTERM)}

    def save_report():
        (run_dir / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")

    def run(name, argv, *, cwd, env, timeout=300, allow_failure=False):
        entry = {"name": name, "command": argv, "cwd": str(cwd),
                 "status": "unreached", "exit_code": None}
        report["commands"].append(entry)
        with subprocess.Popen(argv, cwd=cwd, env=env, stdout=subprocess.PIPE,
                              stderr=subprocess.PIPE, start_new_session=True) as process:
            try:
                stdout, stderr = process.communicate(timeout=timeout)
            except subprocess.TimeoutExpired:
                entry["timed_out"] = True
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                stdout, stderr = process.communicate(timeout=30)
            except BaseException:
                # Popen.__exit__ otherwise waits for an attached Docker CLI
                # after SIGTERM; kill our CLI before final container cleanup.
                entry["interrupted"] = True
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                process.communicate(timeout=30)
                raise
            entry["exit_code"] = code = process.returncode
        entry["status"] = "passed" if code == 0 and not entry.get("timed_out") else "failed"
        if any(secret.encode() in output for secret in passwords.values() for output in (stdout, stderr)):
            entry["output_withheld"] = True
            entry["status"] = "failed"
            save_report()
            raise RuntimeError(f"{name} output contains a disposable credential; output was not saved")
        for stream, output in (("stdout", stdout), ("stderr", stderr)):
            filename = f"{name}.{stream}.log"
            (run_dir / filename).write_bytes(output)
            entry[f"{stream}_log"] = filename
            entry[f"{stream}_sha256"] = digest(output)
        save_report()
        if entry["status"] != "passed" and not allow_failure:
            raise RuntimeError(f"{name} failed (exit {code}); see {run_dir}")
        return stdout

    def docker_run(name, arguments, **kwargs):
        return run(name, docker + arguments, cwd=candidate, env=base_env, **kwargs)

    def rust_run(name, command, envfile, **kwargs):
        container = network + "-" + name.replace("_", "-")
        containers.append(container)
        return docker_run(name, ["run", "--rm", "--pull=never", "--name", container, "--label", ownership_label,
            "--network", network, "--env-file", str(envfile),
            "--mount", f"type=bind,source={candidate},target=/candidate,readonly",
            "--mount", f"type=bind,source={cargo_home},target=/cargo-home",
            "--mount", f"type=bind,source={target_dir},target=/target",
            "--workdir", "/candidate/backend", RUST_IMAGE] + command, **kwargs)

    def owned_resource(kind, name, step):
        listing = [kind, "ls", "--no-trunc"] + (["--all"] if kind == "container" else [])
        ids = docker_run(step + "-lookup", listing + ["--filter", f"name=^{name}$", "--format", "{{.ID}}"])
        identifiers = ids.decode().splitlines()
        if not identifiers:
            return None
        if len(identifiers) != 1:
            raise RuntimeError(f"ambiguous owned-resource name: {name}")
        identifier = identifiers[0]
        field = ".Config.Labels" if kind == "container" else ".Labels"
        label = docker_run(step + "-owner", [kind, "inspect", "--format",
            '{{index ' + field + ' "console.reset-sessions-run"}}', identifier], allow_failure=True)
        if report["commands"][-1]["status"] != "passed":
            # --rm may finish between listing and inspection. Only an
            # independent successful absent-ID readback makes that harmless.
            gone = docker_run(step + "-absent-readback", listing + ["--filter", "id=" + identifier,
                "--format", "{{.ID}}"])
            if not gone.strip():
                return None
            raise RuntimeError(f"resource ownership could not be verified: {name}")
        if label.strip() != nonce.encode():
            raise RuntimeError(f"resource name belongs to another owner; left untouched: {name}")
        return identifier

    def capture_pg_volumes(name):
        identifier = owned_resource("container", pg_name, name)
        if identifier is None:
            return None
        output = docker_run(name, ["container", "inspect", "--format", "{{json .Mounts}}", identifier])
        mounts = json.loads(output)
        volumes.update(mount["Name"] for mount in mounts if mount.get("Type") == "volume")
        report["runtime_resources"]["postgres_anonymous_volumes"] = sorted(volumes)
        return identifier

    def cleanup():
        # A timed-out docker CLI is not proof that its container has stopped.
        # Remove every name registered before its run, even if startup failed.
        for signum in old_handlers:
            signal.signal(signum, signal.SIG_IGN)
        failures = []
        try:
            try:
                identifier = capture_pg_volumes("cleanup-pg-mounts")
                if identifier is not None:
                    docker_run("postgres-log", ["logs", identifier], allow_failure=True)
            except Exception as error:
                failures.append(str(error))
            for index, container in enumerate(reversed(containers)):
                record = {"kind": "container", "name": container, "status": "failed"}
                report["runtime_resources"]["cleanup"].append(record)
                try:
                    identifier = owned_resource("container", container, f"cleanup-container-{index}")
                    record["owned_id"] = identifier
                    if identifier is not None:
                        docker_run(f"cleanup-container-{index}", ["rm", "-fv", identifier], allow_failure=True)
                        record["remove_exit_code"] = report["commands"][-1]["exit_code"]
                        output = docker_run(f"cleanup-container-{index}-readback", ["container", "ls", "--all",
                            "--filter", "id=" + identifier, "--format", "{{.ID}}"])
                        if output.strip():
                            raise RuntimeError(f"owned container survived cleanup: {container}")
                    record["status"] = "passed"
                except Exception as error:
                    record["error"] = str(error)
                    failures.append(str(error))
            # --rm and rm -fv own anonymous-volume deletion. Read it back by ID;
            # do not delete any volume or container belonging to another run.
            for index, volume in enumerate(sorted(volumes)):
                record = {"kind": "anonymous-volume", "name": volume, "status": "failed"}
                report["runtime_resources"]["cleanup"].append(record)
                try:
                    output = docker_run(f"cleanup-volume-{index}-readback", ["volume", "ls",
                        "--filter", f"name=^{volume}$", "--format", "{{.Name}}"])
                    if output.strip():
                        raise RuntimeError(f"owned anonymous volume survived cleanup: {volume}")
                    record["status"] = "passed"
                except Exception as error:
                    record["error"] = str(error)
                    failures.append(str(error))
            record = {"kind": "network", "name": network, "status": "failed"}
            report["runtime_resources"]["cleanup"].append(record)
            try:
                identifier = owned_resource("network", network, "cleanup-network")
                record["owned_id"] = identifier
                if identifier is not None:
                    docker_run("cleanup-network", ["network", "rm", identifier], allow_failure=True)
                    record["remove_exit_code"] = report["commands"][-1]["exit_code"]
                    output = docker_run("cleanup-network-readback", ["network", "ls",
                        "--filter", "id=" + identifier, "--format", "{{.ID}}"])
                    if output.strip():
                        raise RuntimeError("owned network survived cleanup")
                record["status"] = "passed"
            except Exception as error:
                record["error"] = str(error)
                failures.append(str(error))
            if temp is not None:
                try:
                    shutil.rmtree(temp)
                    if temp.exists():
                        raise RuntimeError("disposable secret directory survived cleanup")
                    report["secret_files_removed"] = True
                except Exception as error:
                    failures.append(str(error))
            if failures:
                report["cleanup_error"] = failures
                report["status"] = "failed"
        finally:
            for signum, handler in old_handlers.items():
                signal.signal(signum, handler)
            save_report()

    try:
        for name, image in (("rust", RUST_IMAGE), ("postgres", POSTGRES_IMAGE)):
            image_info = docker_run(name + "-image", ["image", "inspect", "--format",
                "{{json .RepoDigests}}|{{.Architecture}}|{{.Os}}", image]).decode().strip().split("|")
            if (len(image_info) != 3 or image_info[1:] != ["arm64", "linux"]
                    or not any(value.endswith("@" + image.split("@", 1)[1]) for value in json.loads(image_info[0]))):
                raise RuntimeError(f"{name} actual image does not match the pinned Linux arm64 digest")
            report["runtime_images"][name + "_readback"] = image_info
        temp = Path(tempfile.mkdtemp(prefix="reset-sessions-linux-", dir="/private/tmp"))
        pg_env = temp / "postgres.env"
        pg_values = {**passwords, "POSTGRES_DB": "postgres", "POSTGRES_USER": "console_buck_admin",
            "POSTGRES_PASSWORD": passwords["POSTGRES_ADMIN_PASSWORD"], "POSTGRES_HOST": "127.0.0.1",
            "POSTGRES_PORT": "5432", "POSTGRES_ADMIN_USER": "console_buck_admin", "PGUSER": "console_buck_admin",
            "PGDATABASE": "postgres", "PGPASSWORD": passwords["POSTGRES_ADMIN_PASSWORD"]}
        database_url = ("postgresql://console_buck_admin:" + passwords["POSTGRES_ADMIN_PASSWORD"]
            + "@" + pg_name + ":5432/postgres?" + urlencode({"options[console.sqlx_test_bootstrap]": "buck-sqlx-superuser-v1"}))
        test_env = temp / "tests.env"
        test_values = {"DATABASE_URL": database_url, "SQLX_OFFLINE": "true", "CARGO_HOME": "/cargo-home",
            "CARGO_TARGET_DIR": "/target", "RUSTUP_TOOLCHAIN": "1.98.1", "CARGO_BUILD_JOBS": "1",
            "CARGO_INCREMENTAL": "0", "CARGO_PROFILE_DEV_DEBUG": "0", "CARGO_PROFILE_TEST_DEBUG": "0",
            "CONSOLE_TEST_RUNTIME_PASSWORD": passwords["CONSOLE_RT_POSTGRES_PASSWORD"]}
        for path, values in ((pg_env, pg_values), (test_env, test_values)):
            with open(path, "x", opener=lambda path, flags: os.open(path, flags, 0o600)) as file:
                file.write("".join(f"{key}={value}\n" for key, value in values.items()))
            if path.stat().st_mode & 0o777 != 0o600:
                raise RuntimeError("disposable secret env file is not mode 0600")
        docker_run("network-create", ["network", "create", "--internal", "--label", ownership_label, network])
        internal = docker_run("network-readback", ["network", "inspect", "--format", "{{.Internal}}", network])
        if internal.strip() != b"true":
            raise RuntimeError("disposable network is not internal")
        docker_run("postgres-start", ["run", "--detach", "--rm", "--pull=never", "--name", pg_name,
            "--label", ownership_label, "--network", network, "--env-file", str(pg_env), POSTGRES_IMAGE], timeout=120)
        capture_pg_volumes("postgres-mounts")
        if not volumes:
            raise RuntimeError("PostgreSQL anonymous data volume was not captured")
        ports = docker_run("postgres-port-readback", ["container", "inspect", "--format",
            "{{json .HostConfig.PortBindings}}", pg_name])
        if json.loads(ports) not in (None, {}):
            raise RuntimeError("disposable PostgreSQL published a host port")
        deadline = time.monotonic() + 60
        while True:
            docker_run("postgres-ready-" + str(len(report["commands"])), ["exec", pg_name,
                "pg_isready", "-h", "127.0.0.1", "-U", "console_buck_admin", "-d", "postgres"],
                timeout=10, allow_failure=True)
            if report["commands"][-1]["status"] == "passed":
                break
            if time.monotonic() >= deadline:
                raise RuntimeError("PostgreSQL did not become ready before timeout")
            time.sleep(1)
        for tool in ("pg_config", "postgres", "initdb", "pg_ctl", "psql"):
            version = docker_run(tool + "-version", ["exec", pg_name, tool, "--version"]).decode().strip()
            report["postgres_tool_versions"][tool] = version
            major = re.search(r"\bPostgreSQL\)? (\d+)(?:\.\d+)*", version)
            if not major or major.group(1) != "18":
                raise RuntimeError(f"{tool} actual version is not PostgreSQL major 18")
        server = docker_run("postgres-server-version", ["exec", pg_name, "psql", "--host", "127.0.0.1",
            "--no-psqlrc", "--tuples-only", "--no-align", "--set", "ON_ERROR_STOP=1", "--command",
            "SELECT current_setting('server_version_num'), version()"]).decode().strip().split("|", 1)
        if len(server) != 2 or not server[0].isdigit() or int(server[0]) // 10000 != 18:
            raise RuntimeError("actual PostgreSQL server is not major 18")
        report["postgres_server_version"] = {"server_version_num": int(server[0]), "version": server[1]}
        docker_run("topology-copy", ["cp", str(candidate / "ops/postgres-reconcile-topology.sh"), pg_name + ":/topology.sh"])
        docker_run("topology-env-copy", ["cp", str(pg_env), pg_name + ":/topology.env"])
        docker_run("role-topology", ["exec", pg_name, "sh", "-ceu", "set -a; . /topology.env; exec bash /topology.sh"], timeout=120)
        rust_version = rust_run("rust-version", ["rustc", "--version"], test_env).decode().strip()
        cargo_version = rust_run("cargo-version", ["cargo", "--version"], test_env).decode().strip()
        report.update(rust_version=rust_version, cargo_version=cargo_version)
        if not rust_version.startswith("rustc 1.98.1 ") or not cargo_version.startswith("cargo 1.98.1 "):
            raise RuntimeError("actual toolchain does not match the pinned Rust/Cargo 1.98.1")
        for suite, (name, package, target, baseline_minimum) in zip(report["suites"], SUITES):
            suite["status"] = "failed"
            try:
                command = ["cargo", "test", "--locked", "--offline", "-p", package] + (["--lib"] if target == "lib" else ["--test", target])
                discover = rust_run(name + "-discover", command + ["--", "--list"], test_env, timeout=3600)
                discovered_names = [name.decode("utf-8") for name in re.findall(rb"^(.+): test$", discover, re.MULTILINE)]
                discovered = len(discovered_names)
                if discovered != baseline_minimum or len(set(discovered_names)) != discovered:
                    raise RuntimeError(f"{name} did not discover its exact unique population")
                if sorted(discovered_names) != sorted(expectations["expected_discovery"][name]):
                    raise RuntimeError(f"{name} discovery does not match the independently reviewed exact census")
                suite.update(discovered=discovered, discovered_names=discovered_names,
                    selected=9, selected_names=[n for n in discovered_names if n.startswith("reset_sessions::")], expected_filtered=30,
                    executed=None, passed=None, failed=None, ignored=None, measured=None, filtered=None)
                save_report()
                output = rust_run(name, command + ["reset_sessions::", "--", "--test-threads=1", "--format=pretty"], test_env,
                                  timeout=1800, allow_failure=True)
                suite["exit_code"] = report["commands"][-1]["exit_code"]
                outcomes = [(test_name.decode("utf-8"), status.decode("ascii"))
                            for test_name, status in EXECUTED.findall(output)]
                executed_names = [test_name for test_name, _ in outcomes]
                suite.update(executed_names=executed_names, execution_outcomes=dict(outcomes))
                matches = list(RESULT.finditer(output))
                if len(matches) != 1:
                    raise RuntimeError(f"{name} did not emit exactly one Cargo test-result line")
                match = matches[0]
                passed, failed, ignored, measured, filtered = map(int, match.groups()[1:])
                suite.update(executed=passed + failed, passed=passed, failed=failed,
                             ignored=ignored, measured=measured, filtered=filtered)
                complete = (suite["exit_code"] in (0, 101) and passed + failed == suite["selected"]
                    and (ignored, measured, filtered) == (0, 0, 30)
                    and sorted(executed_names) == sorted(suite["selected_names"])
                    and len(set(executed_names)) == len(executed_names)
                    and sum(status == "ok" for _, status in outcomes) == passed
                    and sum(status == "FAILED" for _, status in outcomes) == failed
                    and ((match.group(1) == b"ok" and suite["exit_code"] == 0 and failed == 0)
                         or (match.group(1) == b"FAILED" and suite["exit_code"] == 101 and failed > 0))
                    and not report["commands"][-1].get("timed_out"))
                suite["behavioral_red"] = check_behavioral_failures(output,
                    [test_name for test_name, status in outcomes if status == "FAILED"], expected_by_suite[name], candidate)
                test_stderr = (run_dir / report["commands"][-1]["stderr_log"]).read_bytes()
                if b"panicked at " in test_stderr:
                    suite["behavioral_red"]["status"] = "failed"
                    suite["behavioral_red"]["issues"].append("unexpected panic in test command stderr")
                suite["execution_complete"] = complete
                suite["status"] = ("passed" if complete and failed == 0
                    and suite["behavioral_red"]["status"] == "passed" else "failed")
                save_report()
            except Exception as error:
                suite["error"] = str(error)
                suite["status"] = "failed"
                save_report()
        report["status"] = "passed" if all(suite["status"] == "passed" for suite in report["suites"]) else "failed"
    except Exception as error:
        report["error"] = str(error)
        report["status"] = "failed"
    finally:
        cleanup()
        try:
            final_head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=candidate, text=True).strip()
            final_clean = not subprocess.check_output(["git", "status", "--porcelain"], cwd=candidate)
            final_hashes = {path: digest(Path(path).read_bytes()) for path in report["source_sha256"]}
            expectations_unchanged = (expectations_path.is_file() and not expectations_path.is_symlink()
                                      and expectations_path.read_bytes() == expectations_bytes)
            artifacts_unchanged = all(path.is_file() and not path.is_symlink()
                and digest(path.read_bytes()) == artifact_hashes[str(path)] for path in artifact_paths)
            unchanged = (final_head == head and final_clean and final_hashes == report["source_sha256"]
                         and expectations_unchanged and artifacts_unchanged)
            report["source_revalidation"] = {"status": "passed" if unchanged else "failed",
                                             "candidate_head": final_head, "clean": final_clean,
                                             "red_expectations_unchanged": expectations_unchanged,
                                             "runner_and_probe_unchanged": artifacts_unchanged,
                                             "source_sha256": final_hashes}
            if not unchanged:
                report["status"] = "failed"
        except Exception as error:
            report["source_revalidation"] = {"status": "failed", "error": str(error)}
            report["status"] = "failed"
        save_report()
    report["test_failure_candidate"] = (
        report["status"] == "failed" and "error" not in report
        and "cleanup_error" not in report and "cleanup_temp_retained" not in report
        and report["source_revalidation"]["status"] == "passed"
        and all(suite["execution_complete"] for suite in report["suites"])
        and all(suite["behavioral_red"]["status"] == "passed" for suite in report["suites"])
        and not product_changes
        and all(set(name for name, status in suite["execution_outcomes"].items() if status == "FAILED")
                == set(expected_by_suite[suite["name"]]) for suite in report["suites"])
        and all((suite["failed"], suite["passed"]) == (7, 2) for suite in report["suites"]))
    save_report()
    print(run_dir / "report.json")
    return 0 if report["status"] == "passed" else (1 if report["test_failure_candidate"] else 126)


if __name__ == "__main__":
    try:
        code = main()
    except SystemExit as error:
        code = 0 if error.code == 0 else 126
    except Exception as error:
        print(f"Runner initialization failed ({type(error).__name__}); no admission evidence")
        code = 126
    raise SystemExit(code)
