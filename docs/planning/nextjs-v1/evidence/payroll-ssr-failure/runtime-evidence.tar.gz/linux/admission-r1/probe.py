#!/usr/bin/env python3
"""Run complete reviewed Payroll SSR regressions; only exact behavioral failures may admit implementation."""
import argparse
from pathlib import Path
import subprocess


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--approved-tests-head", required=True)
    parser.add_argument("--approved-red-expectations", type=Path, required=True)
    parser.add_argument("--approved-red-expectations-sha256", required=True)
    args = parser.parse_args()
    candidate = Path("/Users/jasonlee/Developer/frontend/.worktrees/payroll-ssr-failure/backend-fork")
    try:
        head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=candidate, text=True).strip()
        command = ["python3", str(Path(__file__).with_name("run_disposable_pg.py")),
                   "--candidate", str(candidate),
                   "--cargo-home", '/Users/jasonlee/Developer/frontend/.artifacts/acceptance/device-login-source-revocation/linux/cargo-home',
                   "--target-dir", '/Users/jasonlee/Developer/frontend/.artifacts/acceptance/device-login-source-revocation/linux/target',
                   "--expected-head", head,
                   "--approved-tests-head", args.approved_tests_head,
                   "--approved-red-expectations", str(args.approved_red_expectations),
                   "--approved-red-expectations-sha256", args.approved_red_expectations_sha256]
        code = subprocess.run(command, cwd=candidate, check=False).returncode
        # Only exact complete reviewed behavioral failures return 1; all invalid evidence is 126.
        return code if code in (0, 1) else 126
    except (OSError, subprocess.CalledProcessError) as error:
        print(f"Probe infrastructure/custody failure: {error}")
        return 126


if __name__ == "__main__":
    try:
        code = main()
    except SystemExit as error:
        code = 0 if error.code == 0 else 126
    raise SystemExit(code)
