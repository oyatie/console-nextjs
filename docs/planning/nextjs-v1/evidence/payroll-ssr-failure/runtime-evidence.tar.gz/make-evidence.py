"""Save bounded proof only after complete runtime checks; no product source edits."""
from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, io, json, subprocess, tarfile

root = Path('/Users/jasonlee/Developer/frontend/.worktrees/payroll-ssr-failure')
art = Path('/Users/jasonlee/Developer/frontend/.artifacts/acceptance/payroll-ssr-failure')
source = '6d5f612736cc6d2f5e85bf9c3f5274f6317b7a86'
sha = lambda data: hashlib.sha256(data).hexdigest()
write = lambda p, data: p.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == source
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root)
red = art / 'linux/admission-r2/run-20261003T051247.898587Z/report.json'
green = art / 'linux/admission-r2/run-20261003T051812.587681Z/report.json'
nearby = sorted((art / 'linux/nearby-r3').glob('run-*/report.json'))[-1]
reports = [json.loads(p.read_text()) for p in (red, green, nearby)]
assert reports[0]['test_failure_candidate'] and reports[0]['diagnostic_execution_complete']
for d in reports[1:]:
    assert d['candidate_head'] == source and d['status'] == 'passed' and d['diagnostic_execution_complete']
    assert d['source_revalidation']['status'] == 'passed' and d['secret_files_removed']
    assert all(c['status'] == 'passed' for c in d['runtime_resources']['cleanup'])
assert [s['passed'] for s in reports[1]['suites']] == [15]
assert [s['passed'] for s in reports[2]['suites']] == [10, 17, 7]
assert all((s['failed'], s['ignored'], s['measured'], s['filtered']) == (0, 0, 0, 0) for d in reports[1:] for s in d['suites'])
assert json.loads((art / 'source-custody.json').read_text())['status'] == 'passed'
assert 'Ran 18 tests' in (art / 'source-tooling.log').read_text() and (art / 'source-tooling.log').read_text().rstrip().endswith('OK')

m = json.loads((art / 'mechanical-guide.json').read_text())
m['nearby_adapter'] = {'directory': 'linux/nearby-r3', 'runner_sha256': '2f0805355ea294ff36bc8bc380c66535ded1879adce0bdea30c3f4cbfacf1f6c', 'reviewers': ['web_session_owner_v1', 'enrollment_probe_trace'], 'verdict': 'APPROVE', 'execution': 'COMPLETE_GREEN', 'report': str(nearby.relative_to(art)), 'report_sha256': sha(nearby.read_bytes())}
m['reviewed_attempts'].append({'directory': 'linux/nearby-r2', 'runner_sha256': '237e236c138360afb0304b0200723072cf02159d6832243c91b0e19579f6ed55', 'status': 'APPROVED_NOT_EXECUTED_SUPERSEDED', 'reason': 'Supply already-pinned Clippy image after R1 missing-tool failure.'})
m['reviewed_attempts'][-2]['additional_finding'] = 'Base Rust image has no Clippy; R1 returned126 and carries no whole-run acceptance credit.'
write(art / 'mechanical-guide.json', m)

out = root / 'docs/planning/nextjs-v1/evidence/payroll-ssr-failure'
out.mkdir(parents=True, exist_ok=False)
entries = []
for f in sorted(art.rglob('*')):
    if not f.is_file():
        continue
    assert not f.is_symlink()
    rel = f.relative_to(art).as_posix()
    if rel.startswith('hosted/') or f.suffix not in ('.py', '.json', '.log'):
        continue
    entries.append((rel, f.read_bytes()))
archive = out / 'runtime-evidence.tar.gz'
with archive.open('wb') as file:
    with gzip.GzipFile(fileobj=file, mode='wb', filename='', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w') as tar:
            for name, data in entries:
                info = tarfile.TarInfo(name); info.size = len(data); info.mode = 0o644
                tar.addfile(info, io.BytesIO(data))
manifest = {'schema_version': 1, 'archive_sha256': sha(archive.read_bytes()), 'regular_files': len(entries), 'bytes': sum(len(b) for _, b in entries), 'members': [{'path': n, 'sha256': sha(b), 'bytes': len(b)} for n, b in entries]}
write(out / 'manifest.json', manifest)
with tarfile.open(archive, 'r:gz') as tar:
    actual = [(f.name, tar.extractfile(f).read()) for f in tar.getmembers() if f.isfile()]
assert actual == entries

limits = ['First100 SSR pagination remains incomplete.', 'Single-site real Router/PostgreSQL proof, not genuine Next/browser/passkey/identity-proofing acceptance.', 'Current authority at emission, two-site durability/fencing, full HR/Org/Payroll/Foundry, MVP and launch remain HOLD.', 'No live institutional execution, payment collection, deployment or exposure.']
def summary(path, d):
    return {'archive_member': str(path.relative_to(art)), 'sha256': sha(path.read_bytes()), 'candidate_head': d['candidate_head'], 'status': d['status'], 'runner_sha256': d['runner_sha256'], 'diagnostic_execution_complete': d['diagnostic_execution_complete'], 'suites': [{k: s[k] for k in ('name', 'discovered', 'executed', 'passed', 'failed', 'ignored', 'measured', 'filtered')} for s in d['suites']]}
evidence = {'schema_version': 1, 'recorded_at': datetime.now(timezone.utc).isoformat(), 'scope': 'Existing Payroll SSR authorized failure-state repair only.', 'base': '9e6ddb687e2eaaf031beac4018bf568c37020090', 'runtime_source_candidate': source, 'design_sha256': '0b8f1d37228151cc8fc524e48b59a6a33c5784f13cd9e467b0458228cf629603', 'approved_tests_head': 'f3117e680be2beaae9e3784a4bf1501af1cd5e6b', 'tests_sha256': '7fabdb7b5dc22f1865dbdcac10f7e869e5962e54ca270fde3030b7d7858221f3', 'bundle': {'archive': str(archive.relative_to(root)), 'sha256': manifest['archive_sha256'], 'manifest': str((out/'manifest.json').relative_to(root)), 'manifest_sha256': sha((out/'manifest.json').read_bytes()), 'regular_files': len(entries), 'verified': True}, 'red': summary(red, reports[0]), 'green': summary(green, reports[1]), 'nearby': summary(nearby, reports[2]), 'quality': {'source_tooling': {'command': "python3 -m unittest discover -s tools -p 'test_*.py'", 'executed': 18, 'failed': 0, 'artifact': 'source-tooling.log', 'sha256': sha((art/'source-tooling.log').read_bytes())}, 'source_custody': {'status': 'passed', 'artifact': 'source-custody.json', 'sha256': sha((art/'source-custody.json').read_bytes())}, 'format': {'artifact': 'host-format.json', 'sha256': sha((art/'host-format.json').read_bytes()), 'commands': json.loads((art/'host-format.json').read_text())['commands']}, 'clippy': [{'name': c['name'], 'command': c['command'], 'exit_code': c['exit_code']} for c in reports[2]['commands'] if c['name'] in ('payroll-app-clippy', 'payroll-rest-ui-clippy')], 'clippy_version': reports[2]['clippy_version']}, 'retained_rejections': [{'attempt': 'admission-r1', 'reason': 'Unsupported copied lock/blocker evidence phrase; corrected in R2, no source-admission credit.'}, {'attempt': 'nearby-r1', 'reason': 'Incomplete REST library census and absent Clippy; whole-run126, no whole-run acceptance credit.'}, {'attempt': 'nearby-r2', 'reason': 'Reviewed but unexecuted; superseded to supply the existing pinned Clippy image.'}, {'attempt': 'source-custody-import-1', 'reason': 'Import path error; no custody acceptance credit, corrected invocation passed.'}], 'proof_limits': limits, 'merge_status': 'PENDING_EXACT_HEAD_COMMENT_AND_PROTECTED_QUEUE'}
write(root/'docs/planning/nextjs-v1/payroll-ssr-failure-evidence.json', evidence)

p=root/'docs/planning/nextjs-v1/payroll-ssr-failure-review.json';r=json.loads(p.read_text())
r['tests']['runtime_discovery']='15 complete RED11/4 -> unchanged GREEN15/15; zero ignored/measured/filtered'
r['implementation']['status']='GREEN_SOURCE_APPROVED_PENDING_EXACT_HEAD_COMMENT_AND_PROTECTED_QUEUE'
r['source_reviews']=[{'reviewer': n, 'candidate': source, 'verdict': 'APPROVE', 'findings': []} for n in ['native_attendance_owner_trace','web_session_owner_v1']]
r['runtime_review']={'reviewer':'native_attendance_owner_trace','candidate':source,'verdict':'CONFIRMED_IDENTICAL_PROBE_GREEN','report_sha256':sha(green.read_bytes())}
r['adapter_reviews'].extend([{'revision':'nearby-r1','verdict':'REJECTED_WHOLE_RUN','findings':['Incomplete4-test census; complete REST lib actually has10 tests.','Clippy absent from base image.'],'disposition':'Raw attempt retained; no test change or whole-run acceptance credit.'},{'revision':'nearby-r2','runner_sha256':'237e236c138360afb0304b0200723072cf02159d6832243c91b0e19579f6ed55','reviewers':['web_session_owner_v1','enrollment_probe_trace'],'verdict':'APPROVE_NOT_EXECUTED_SUPERSEDED'},{'revision':'nearby-r3','runner_sha256':'2f0805355ea294ff36bc8bc380c66535ded1879adce0bdea30c3f4cbfacf1f6c','reviewers':['web_session_owner_v1','enrollment_probe_trace'],'verdict':'APPROVE','outcome':'34/34 complete GREEN; strict Clippy passed'}])
names=['Cartesian doubt','Essentialism / YAGNI',"Chesterton's Fence",'Contrarian / outside-the-box','Socratic','Pragmatism','Red Team','Systems Thinking','Operability / Day-2','Opportunity Cost','Blast-radius / cell-based','Constant-work / anti-fragility','Shared-nothing / eventual consistency','FinOps / unit-cost','Telemetry-first','Zero-trust / defense-in-depth']
conclusions=['Exact intended RED and unchanged15-test GREEN verified; rejected attempts retained.','Small outcome and shared helper; no new infrastructure.','Current authority, RLS, audited snapshot and existing rendering preserved.','Query and audit faults independently refuse fabricated empty state.','Tests prove valid authority and REST refusal before SSR failure expectation.','Existing Korean failure copy and reload path realize the bounded repair.','Missing/invalid/revoked/wrong-tier and Company boundaries tested; no raw data/error/hydration on failure.','Count/page/audit remain one coherent owner transaction; failed audit releases no rows.','Real faults, restoration and exact audit deltas execute in GREEN.','Repairs an actionable journey; broader Next/MVP obligations remain open.','Two product files; no schema/dependency/calculation/other-domain/live-service changes.','First100 bound and unchanged total-count cost; no full-pagination/capacity claim.','Explicit Payroll outcome independent of unchanged Org/HR composition; no new coordination.','Existing owner/components/tool images; no added recurring services.','Exact test accounting and rejected census/tool/evidence attempts remain visible.','Both helper callers establish current principal and PayrollRunRead; SSR carries no raw errors.']
r['sixteen_lens_audit']={'reviewer':'enrollment_probe_trace','candidate':source,'verdict':'APPROVE_BOUNDED_SOURCE_TEST_CI','findings':[],'lenses':[{'id':i,'name':n,'conclusion':c} for i,(n,c) in enumerate(zip(names,conclusions),1)],'limits':limits}
write(p,r)

p=root/'docs/planning/nextjs-v1/requirements-and-evidence.json';req=json.loads(p.read_text());b=next(e for e in req['requirements'] if e['id']=='B06')
b['implementation_owners'].extend(['console_payroll_rest::PayrollRestState::visible_run_summaries','console_app::compose_ui_screens'])
b['contracts'].append('Bounded SSR omission/authorized empty/populated/failure outcome through existing audited PayrollRunRead owner; same REST contract, no raw error or rows/hydration after failure. First100 pagination and full module remain incomplete.')
b['tests'].append('Payroll SSR complete health_readiness15/15; neighboring REST lib10/API17/UIlib7 all passed, zero skips/filters; strict relevant Clippy. Real single-site PostgreSQL/Router proof only.')
b['evidence'].append('payroll-ssr-failure-evidence.json sha256:'+sha((root/'docs/planning/nextjs-v1/payroll-ssr-failure-evidence.json').read_bytes())+'; runtime source '+source+'; independently reviewed intended RED4/15 -> unchanged GREEN15/15. Full module status stays unverified.')
assert b['status']=='unverified'
write(p,req)
print('saved',len(entries),'regular evidence files; archive',manifest['archive_sha256'])
